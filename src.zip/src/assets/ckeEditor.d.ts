declare module 'src/assets/ckeEditor' {
    const Editor: any;
    export default Editor;
  }
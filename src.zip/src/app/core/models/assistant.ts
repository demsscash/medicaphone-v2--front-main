export interface Assistant {
  id: string;
  name: string;
  email: string;
  phone?: string;
  specialty?: string;
  photo: string;
  address: string;
  idCard: string;
}

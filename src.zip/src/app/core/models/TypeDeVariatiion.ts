export enum TypeDeVariatiion {
    VARIABLE = 'VARIABLE',
    STATIONNAIRE = 'STATIONNAIRE',
    FIXE = 'FIXE'
  }
  
export interface RapportGenetiqueHist {
  id: string;
  label: string;
  valeur: number;
  createdBy: string;
  creationDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
}
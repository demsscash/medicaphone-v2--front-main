import { ImageSecurePipe } from "./image-secure.pipe";


describe('ImageSecurePipe', () => {
  it('create an instance', () => {
    // const pipe = new ImageSecurePipe();
    // expect(pipe).toBeTruthy();
  });
});
